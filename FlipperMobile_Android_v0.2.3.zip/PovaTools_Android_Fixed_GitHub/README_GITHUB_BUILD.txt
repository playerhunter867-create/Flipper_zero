GitHub Actions build

1. Upload the contents of this folder to a GitHub repository.
2. Push to the main branch, or open Actions and run "Build Flipper Mobile APK" manually.
3. The workflow installs JDK 17 and Android SDK 35.
4. It verifies gradle/wrapper/gradle-wrapper.jar and its SHA-256.
5. It runs ./gradlew --no-daemon clean assembleDebug.
6. The APK is uploaded as artifact "FlipperMobile-v0.2.3-debug".

The project uses Gradle 8.11.1, which is the minimum required Gradle version for Android Gradle Plugin 8.9.
The wrapper launcher in this repository is compiled for Java 17, so it is compatible with the JDK used by CI.
