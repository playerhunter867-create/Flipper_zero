# Build notes

Known-good toolchain for this project:
- Android Gradle Plugin 8.9.3
- Gradle 8.11.1
- JDK 17
- compileSdk/targetSdk 35

The Gradle wrapper launcher is compiled for Java 17 to avoid the class-file-65/JDK17 mismatch.
The Gradle 8.11.1 distribution is pinned by SHA-256 in gradle-wrapper.properties.
