
package com.flippermobile

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private var irManager: ConsumerIrManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        val rawInput = findViewById<EditText>(R.id.rawInput)

        irManager = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

        if (irManager?.hasIrEmitter() == true) {
            statusText.text = "IR Blaster найден"
        } else {
            statusText.text = "IR Blaster не найден"
        }

        findViewById<Button>(R.id.btnPower).setOnClickListener {
            sendRaw(38000, NEC_POWER)
        }

        findViewById<Button>(R.id.btnVolUp).setOnClickListener {
            sendRaw(38000, NEC_VOL_UP)
        }

        findViewById<Button>(R.id.btnVolDown).setOnClickListener {
            sendRaw(38000, NEC_VOL_DOWN)
        }

        findViewById<Button>(R.id.btnMute).setOnClickListener {
            sendRaw(38000, NEC_MUTE)
        }

        findViewById<Button>(R.id.btnSendRaw).setOnClickListener {
            val values = rawInput.text.toString()
                .trim()
                .split(Regex("\\s+"))
                .mapNotNull { it.toIntOrNull() }
                .toIntArray()

            if (values.isNotEmpty()) {
                sendRaw(38000, values)
            }
        }
    }

    private fun sendRaw(freq: Int, pattern: IntArray) {
        try {
            irManager?.transmit(freq, pattern)
            statusText.text = "RAW отправлен (${pattern.size} импульсов)"
        } catch (e: Exception) {
            statusText.text = "Ошибка: ${e.message}"
        }
    }

    companion object {
        val NEC_POWER = intArrayOf(
            9000,4500,560,560,560,1690,560,560,560,1690,
            560,1690,560,560,560,1690,560,560,560,560,
            560,1690,560,560,560,1690,560,560,560,560
        )

        val NEC_VOL_UP = intArrayOf(
            9000,4500,560,560,560,1690,560,560,560,560,
            560,1690,560,560,560,560,560,1690,560,560
        )

        val NEC_VOL_DOWN = intArrayOf(
            9000,4500,560,1690,560,560,560,560,560,1690,
            560,560,560,1690,560,560,560,560,560,1690
        )

        val NEC_MUTE = intArrayOf(
            9000,4500,560,560,560,1690,560,1690,560,560,
            560,560,560,1690,560,560,560,1690,560,560
        )
    }
}
