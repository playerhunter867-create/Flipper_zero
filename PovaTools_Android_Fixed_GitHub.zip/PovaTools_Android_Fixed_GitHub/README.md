# PovaTools 1.0.1

This build removes Kotlin, AndroidX, Material and third-party dependencies and uses
a single native Java Activity. CI uses JDK 17, Android SDK 35 and Gradle 8.9.
The workflow runs a clean debug build and verifies the APK before uploading it.

The app provides NFC status, BLE scanning, USB enumeration, device info, sensors,
flashlight, network status, vibration and Consumer IR capability detection.
