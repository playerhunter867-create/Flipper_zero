package com.povatools;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.nfc.NfcAdapter;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    static final int BG=0xff050505, PANEL=0xff111111, WHITE=0xfff5f5f5, LIME=0xffd7ff55, MUTED=0xff9a9a9a;
    static final int BT_REQ=100;
    BluetoothLeScanner scanner;
    ScanCallback callback;
    Button scanButton;
    TextView scanOutput;
    final Map<String,String> devices=new LinkedHashMap<>();

    @Override public void onCreate(Bundle b){super.onCreate(b);main();}
    @Override protected void onDestroy(){stopScan();super.onDestroy();}

    TextView text(String s,float size,int color){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setPadding(8,8,8,12); return v;
    }
    Button button(String s,final Runnable r){
        Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(14);
        b.setOnClickListener(v->r.run()); return b;
    }
    LinearLayout root(String title){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setBackgroundColor(BG);
        TextView t=text(title+"  ●",18,LIME); t.setGravity(Gravity.CENTER_VERTICAL); r.addView(t,new LinearLayout.LayoutParams(-1,60));
        return r;
    }
    LinearLayout box(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(12,8,12,20);return b;}

    void main(){
        stopScan(); LinearLayout r=root("POVATOOLS"); ScrollView s=new ScrollView(this); LinearLayout b=box();
        b.addView(text("MAIN MENU",24,WHITE)); b.addView(text("Android hardware toolkit • v1.0.1",15,MUTED));
        String[] a={"📡 NFC / NDEF","🔵 BLE Scanner","🔌 USB Devices","📱 Device Info","🧭 Sensors",
        "🔦 Flashlight","📶 Network","📳 Vibration","📺 IR / Hardware","⚙ Android Settings","ℹ About"};
        for(int i=0;i<a.length;i++){final int n=i;Button x=button(a[i],()->tool(n,a[n]));b.addView(x,new LinearLayout.LayoutParams(-1,60));}
        s.addView(b);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);
    }

    void tool(int n,String title){
        stopScan();LinearLayout r=root(title);ScrollView s=new ScrollView(this);LinearLayout b=box();b.addView(text(title,22,WHITE));
        switch(n){case 0:nfc(b);break;case 1:ble(b);break;case 2:usb(b);break;case 3:info(b);break;case 4:sensors(b);break;
        case 5:flash(b);break;case 6:network(b);break;case 7:vibrate(b);break;case 8:ir(b);break;
        case 9:b.addView(button("OPEN ANDROID SETTINGS",()->startActivity(new Intent(Settings.ACTION_SETTINGS))));break;
        default:b.addView(text("PovaTools 1.0.1\n\nNative Android hardware toolkit.\nUses public Android APIs only.",15,MUTED));}
        b.addView(button("← BACK",this::main));s.addView(b);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);
    }

    void nfc(LinearLayout b){
        NfcAdapter a=NfcAdapter.getDefaultAdapter(this);
        b.addView(text(a==null?"NFC hardware: NOT PRESENT":"NFC hardware: PRESENT • "+(a.isEnabled()?"ON":"OFF"),15,MUTED));
        b.addView(button("OPEN NFC SETTINGS",()->startActivity(new Intent(Settings.ACTION_NFC_SETTINGS))));
    }
    void ble(LinearLayout b){
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
        if(a==null){b.addView(text("Bluetooth hardware: NOT PRESENT",15,MUTED));return;}
        b.addView(text("Bluetooth: "+(a.isEnabled()?"ON":"OFF"),15,MUTED));
        scanButton=button("START BLE SCAN",this::toggleScan);b.addView(scanButton);
        b.addView(text("Nearby BLE advertisements only.",14,MUTED));
        scanOutput=text("No scan results.",13,WHITE);b.addView(scanOutput);
    }
    void toggleScan(){
        if(callback!=null){stopScan();if(scanButton!=null)scanButton.setText("START BLE SCAN");return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},BT_REQ);return;}
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null)return;
        if(!a.isEnabled()){startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));return;}
        scanner=a.getBluetoothLeScanner();devices.clear();
        callback=new ScanCallback(){
            @Override public void onScanResult(int type,ScanResult x){
                BluetoothDevice d=x.getDevice();String addr="unknown",name="Unknown";
                try{addr=d.getAddress();if(x.getScanRecord()!=null&&x.getScanRecord().getDeviceName()!=null)name=x.getScanRecord().getDeviceName();}catch(SecurityException ignored){}
                devices.put(addr,name+" • "+addr+" • RSSI "+x.getRssi()+" dBm");
                runOnUiThread(()->{StringBuilder z=new StringBuilder();for(String q:devices.values())z.append(q).append("\n\n");scanOutput.setText(z.toString());});
            }
            @Override public void onScanFailed(int e){runOnUiThread(()->scanOutput.setText("BLE scan failed: "+e));}
        };
        try{scanner.startScan(callback);scanButton.setText("STOP BLE SCAN");}catch(SecurityException e){scanOutput.setText("Bluetooth permission required.");}
    }
    void stopScan(){if(scanner!=null&&callback!=null)try{scanner.stopScan(callback);}catch(Exception ignored){}scanner=null;callback=null;}

    void usb(LinearLayout b){
        android.hardware.usb.UsbManager m=(android.hardware.usb.UsbManager)getSystemService(Context.USB_SERVICE);
        if(m==null||m.getDeviceList().isEmpty()){b.addView(text("No USB devices visible.",15,MUTED));return;}
        for(android.hardware.usb.UsbDevice d:m.getDeviceList().values())b.addView(text("VID "+d.getVendorId()+" • PID "+d.getProductId()+"\n"+d.getProductName(),15,WHITE));
    }
    void info(LinearLayout b){b.addView(text("Android "+Build.VERSION.RELEASE+" / SDK "+Build.VERSION.SDK_INT+"\nManufacturer: "+Build.MANUFACTURER+"\nModel: "+Build.MODEL+"\nDevice: "+Build.DEVICE+"\nABI: "+java.util.Arrays.toString(Build.SUPPORTED_ABIS),15,WHITE));}
    void sensors(LinearLayout b){
        SensorManager s=(SensorManager)getSystemService(Context.SENSOR_SERVICE);int[] t={1,4,2,5,8,6};String[] n={"Accelerometer","Gyroscope","Magnetometer","Light","Proximity","Pressure"};
        for(int i=0;i<t.length;i++)b.addView(text(n[i]+": "+(s.getDefaultSensor(t[i])!=null?"AVAILABLE":"not available"),15,MUTED));
    }
    void flash(LinearLayout b){
        CameraManager c=(CameraManager)getSystemService(Context.CAMERA_SERVICE);String id=null;
        try{for(String x:c.getCameraIdList()){if(Boolean.TRUE.equals(c.getCameraCharacteristics(x).get(CameraCharacteristics.FLASH_INFO_AVAILABLE))){id=x;break;}}}catch(Exception ignored){}
        if(id==null){b.addView(text("Flashlight unavailable.",15,MUTED));return;}final String cid=id;final boolean[] on={false};
        Button x=button("FLASHLIGHT: OFF",()->{});x.setOnClickListener(v->{try{on[0]=!on[0];c.setTorchMode(cid,on[0]);x.setText("FLASHLIGHT: "+(on[0]?"ON":"OFF"));}catch(Exception e){x.setText("FLASHLIGHT ERROR");}});
        b.addView(x);
    }
    void network(LinearLayout b){
        ConnectivityManager m=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkCapabilities c=m.getNetworkCapabilities(m.getActiveNetwork());String t="Offline";
        if(c!=null){if(c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))t="Wi-Fi";else if(c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))t="Mobile";else if(c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))t="Ethernet";}
        b.addView(text("Transport: "+t+"\nValidated: "+(c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)),15,MUTED));
    }
    void vibrate(LinearLayout b){b.addView(button("TEST VIBRATION",()->{Vibrator v=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);if(v!=null&&v.hasVibrator()){if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(180,VibrationEffect.DEFAULT_AMPLITUDE));else v.vibrate(180);}}));}
    void ir(LinearLayout b){b.addView(text("Consumer IR: "+(getPackageManager().hasSystemFeature(PackageManager.FEATURE_CONSUMER_IR)?"AVAILABLE":"not detected"),15,MUTED));b.addView(text("Sub-GHz/RFID/GPIO/RF functions require dedicated hardware; this app does not emulate unavailable hardware.",14,MUTED));}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);}
}
