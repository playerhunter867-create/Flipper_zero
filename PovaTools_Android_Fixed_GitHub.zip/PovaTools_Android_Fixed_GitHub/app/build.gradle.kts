plugins {
    id("com.android.application")
}
android {
    namespace = "com.povatools"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.povatools"
        minSdk = 26
        targetSdk = 35
        versionCode = 101
        versionName = "1.0.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
