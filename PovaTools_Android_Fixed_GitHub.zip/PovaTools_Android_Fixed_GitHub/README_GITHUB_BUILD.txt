Исправленная структура проекта для GitHub Actions.

Что сделано:
- gradlew вынесен в корень проекта
- добавлен .github/workflows/android.yml
- включена автоматическая сборка APK через GitHub Actions

Как собрать APK:
1. Загрузите содержимое архива в новый репозиторий GitHub.
2. Откройте вкладку Actions.
3. Запустите workflow "Android APK".
4. Скачайте app-debug.apk из Artifacts.
