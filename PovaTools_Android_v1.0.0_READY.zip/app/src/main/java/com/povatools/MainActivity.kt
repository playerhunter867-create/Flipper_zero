package com.povatools

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.*
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val bg = 0xFF050505.toInt()
    private val panel = 0xFF111111.toInt()
    private val panel2 = 0xFF181818.toInt()
    private val white = 0xFFF5F5F5.toInt()
    private val lime = 0xFFD7FF55.toInt()
    private val muted = 0xFF9A9A9A.toInt()

    private val bleResults = linkedMapOf<String, String>()
    private var bleScanner: BluetoothLeScanner? = null
    private var bleCallback: ScanCallback? = null
    private var scanButton: Button? = null

    private val permissionRequest = 500

    private val tools = listOf(
        "📡  NFC / NDEF",
        "🔵  BLE Scanner",
        "🔌  USB Devices",
        "📱  Device Info",
        "🧭  Sensors",
        "🔦  Flashlight",
        "📶  Network",
        "📳  Vibration",
        "📺  IR / Hardware",
        "⚙  Android Settings",
        "ℹ  About"
    )

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        showMain()
    }

    override fun onDestroy() {
        stopBleScan()
        super.onDestroy()
    }

    private fun base(title: String = "POVATOOLS"): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 6, 16, 6)
        }
        val t = TextView(this).apply {
            text = title
            textColor = white
            textSize = 17f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        bar.addView(t, LinearLayout.LayoutParams(0, 58, 1f))
        val dot = TextView(this).apply {
            text = "●"
            textColor = lime
            textSize = 18f
        }
        bar.addView(dot)
        root.addView(bar)
        return root
    }

    private fun button(text: String, click: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textColor = white
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(panel)
            setPadding(18, 4, 18, 4)
            setOnClickListener { click() }
        }

    private fun label(text: String, size: Float = 15f): TextView =
        TextView(this).apply {
            this.text = text
            textColor = muted
            textSize = size
            setPadding(4, 8, 4, 12)
        }

    private fun showMain() {
        stopBleScan()
        val root = base()
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 24)
        }

        box.addView(TextView(this).apply {
            text = "MAIN MENU"
            textColor = white
            textSize = 22f
            setPadding(4, 8, 4, 8)
        })
        box.addView(label("Safe Android hardware toolkit • v1.0.0"))

        tools.forEachIndexed { index, name ->
            box.addView(
                button(name) { showTool(index, name) },
                LinearLayout.LayoutParams(-1, 62).apply { setMargins(0, 0, 0, 7) }
            )
        }

        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showTool(index: Int, title: String) {
        stopBleScan()
        val root = base(title)
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 24)
        }

        box.addView(TextView(this).apply {
            text = title
            textColor = white
            textSize = 22f
        })

        when (index) {
            0 -> nfcScreen(box)
            1 -> bleScreen(box)
            2 -> usbScreen(box)
            3 -> deviceScreen(box)
            4 -> sensorScreen(box)
            5 -> flashlightScreen(box)
            6 -> networkScreen(box)
            7 -> vibrationScreen(box)
            8 -> irScreen(box)
            9 -> box.addView(button("Open Android Settings") {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }, LinearLayout.LayoutParams(-1, 60))
            10 -> box.addView(label(
                "PovaTools 1.0.0\n\n" +
                "A native Android hardware utility toolkit.\n" +
                "This release uses public Android APIs and does not perform unauthorized " +
                "cloning, credential capture, RF jamming, HID injection, or device attacks."
            ))
        }

        box.addView(button("← BACK") { showMain() },
            LinearLayout.LayoutParams(-1, 60).apply { setMargins(0, 18, 0, 0) })

        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun nfcScreen(box: LinearLayout) {
        val adapter = NfcAdapter.getDefaultAdapter(this)
        val state = when {
            adapter == null -> "NFC hardware: NOT PRESENT"
            !adapter.isEnabled -> "NFC hardware: PRESENT • NFC is OFF"
            else -> "NFC hardware: PRESENT • NFC is ON"
        }
        box.addView(label(state))
        box.addView(label(
            "NFC reading is handled by Android's NFC dispatch system. " +
            "This app can inspect NDEF-compatible tags when the phone presents a tag."
        ))
        box.addView(button("Open NFC Settings") {
            startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
        }, LinearLayout.LayoutParams(-1, 60))
    }

    private fun bleScreen(box: LinearLayout) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            box.addView(label("Bluetooth hardware: NOT PRESENT"))
            return
        }
        box.addView(label("Bluetooth adapter: ${if (adapter.isEnabled) "ON" else "OFF"}"))
        scanButton = button("START BLE SCAN") { toggleBleScan(box) }
        box.addView(scanButton, LinearLayout.LayoutParams(-1, 60))
        box.addView(label("Only nearby BLE advertisements are displayed. No pairing or intrusion is performed."))

        val resultsView = TextView(this).apply {
            textColor = white
            textSize = 13f
            setPadding(4, 8, 4, 8)
            tag = "ble_results"
        }
        box.addView(resultsView)
    }

    private fun toggleBleScan(box: LinearLayout) {
        if (bleCallback != null) {
            stopBleScan()
            scanButton?.text = "START BLE SCAN"
            return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            ), permissionRequest)
            return
        }

        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        if (!adapter.isEnabled) {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }

        bleResults.clear()
        bleScanner = adapter.bluetoothLeScanner
        bleCallback = object : ScanCallback() {
            override fun onScanResult(type: Int, result: ScanResult) {
                val device = result.device
                val name = result.scanRecord?.deviceName ?: "Unknown"
                val address = safeAddress(device)
                val line = "$name  •  $address  •  RSSI ${result.rssi} dBm"
                bleResults[address] = line
                runOnUiThread {
                    val v = findBleText(box)
                    v.text = bleResults.values.joinToString("\n\n").ifEmpty { "No BLE advertisements yet." }
                }
            }

            override fun onScanFailed(errorCode: Int) {
                runOnUiThread {
                    findBleText(box).text = "BLE scan failed: $errorCode"
                }
            }
        }
        bleScanner?.startScan(bleCallback)
        scanButton?.text = "STOP BLE SCAN"
    }

    private fun findBleText(box: LinearLayout): TextView {
        for (i in 0 until box.childCount) {
            val v = box.getChildAt(i)
            if (v is TextView && v.tag == "ble_results") return v
        }
        return TextView(this)
    }

    private fun safeAddress(device: BluetoothDevice): String =
        if (Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
            device.address
        else "permission required"

    private fun stopBleScan() {
        val scanner = bleScanner
        val callback = bleCallback
        if (scanner != null && callback != null) {
            try { scanner.stopScan(callback) } catch (_: SecurityException) {}
        }
        bleScanner = null
        bleCallback = null
    }

    private fun usbScreen(box: LinearLayout) {
        val manager = getSystemService(Context.USB_SERVICE) as android.hardware.usb.UsbManager
        if (manager.deviceList.isEmpty()) {
            box.addView(label("No USB devices currently visible to Android."))
            return
        }
        manager.deviceList.values.forEach { d ->
            box.addView(label(
                "${d.productName ?: "USB device"}\n" +
                "VID ${d.vendorId} • PID ${d.productId}\n" +
                "Manufacturer: ${d.manufacturerName ?: "unknown"}"
            ))
        }
    }

    private fun deviceScreen(box: LinearLayout) {
        val b = Build.VERSION
        box.addView(label(
            "Android: ${b.RELEASE} (SDK ${b.SDK_INT})\n" +
            "Manufacturer: ${Build.MANUFACTURER}\n" +
            "Model: ${Build.MODEL}\n" +
            "Device: ${Build.DEVICE}\n" +
            "ABI: ${Build.SUPPORTED_ABIS.joinToString()}\n" +
            "App: PovaTools 1.0.0"
        ))
    }

    private fun sensorScreen(box: LinearLayout) {
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val types = listOf(
            Sensor.TYPE_ACCELEROMETER to "Accelerometer",
            Sensor.TYPE_GYROSCOPE to "Gyroscope",
            Sensor.TYPE_MAGNETIC_FIELD to "Magnetometer",
            Sensor.TYPE_LIGHT to "Light sensor",
            Sensor.TYPE_PROXIMITY to "Proximity",
            Sensor.TYPE_PRESSURE to "Barometer"
        )
        types.forEach { (type, name) ->
            val s = sm.getDefaultSensor(type)
            box.addView(label("$name: ${if (s != null) "AVAILABLE" else "not available"}"))
        }
    }

    private fun flashlightScreen(box: LinearLayout) {
        val camera = getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
        val id = camera.cameraIdList.firstOrNull { camera.getCameraCharacteristics(it)
            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }

        if (id == null) {
            box.addView(label("Camera flashlight: not available"))
            return
        }

        var on = false
        val b = button("FLASHLIGHT: OFF") {
            on = !on
            try {
                camera.setTorchMode(id, on)
                it as Button
                it.text = "FLASHLIGHT: ${if (on) "ON" else "OFF"}"
            } catch (e: Exception) {
                (it as Button).text = "FLASHLIGHT ERROR"
            }
        }
        box.addView(b, LinearLayout.LayoutParams(-1, 60))
    }

    private fun networkScreen(box: LinearLayout) {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val caps = if (n != null) cm.getNetworkCapabilities(n) else null
        val type = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile data"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            else -> "Offline / unknown"
        }
        box.addView(label("Current transport: $type"))
        box.addView(label("Validated internet: ${caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true}"))
    }

    private fun vibrationScreen(box: LinearLayout) {
        box.addView(button("TEST VIBRATION") {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(180, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(180)
            }
        }, LinearLayout.LayoutParams(-1, 60))
    }

    private fun irScreen(box: LinearLayout) {
        val consumer = packageManager.hasSystemFeature(PackageManager.FEATURE_CONSUMER_IR)
        box.addView(label(
            "Consumer IR emitter: ${if (consumer) "AVAILABLE" else "not detected"}"
        ))
        box.addView(label(
            "Sub-GHz, RFID/iButton emulation, RF jamming and similar functions require " +
            "hardware that Android phones normally do not expose. PovaTools 1.0 only reports " +
            "capabilities and does not implement unauthorized cloning or interference."
        ))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == permissionRequest &&
            results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) {
            Toast.makeText(this, "Permissions granted. Open BLE Scanner again.", Toast.LENGTH_SHORT).show()
        }
    }
}
