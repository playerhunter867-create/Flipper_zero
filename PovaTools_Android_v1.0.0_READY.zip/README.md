# PovaTools Android 1.0.0

Native Android hardware utility toolkit.

## Included in 1.0.0
- NFC hardware/status information
- BLE scanner using public Android BLE APIs
- USB device enumeration
- Android/device/ABI information
- Sensor availability
- Camera flashlight test
- Current network transport/status
- Vibration test
- Consumer IR capability detection
- Android Settings shortcut
- Dark terminal-style UI

## Important limitations
PovaTools is an Android app, not a Flipper Zero replacement at the hardware level.
A normal Android phone cannot directly provide arbitrary Sub-GHz radio, RFID/iButton
emulation, GPIO, or RF jamming. Those functions require compatible external hardware.

This release deliberately does not implement credential capture, unauthorized cloning,
RF interference/jamming, HID injection, or other attack functionality.

## Build on GitHub Actions
1. Put the CONTENTS of this project in the repository root.
2. Push to `main`, or open Actions → Build PovaTools APK → Run workflow.
3. Download the artifact `PovaTools-v1.0.0-debug`.

The workflow uses JDK 17, installs Gradle 8.10.2 explicitly, uses Android SDK 35,
and performs a clean debug build. This avoids depending on a missing wrapper JAR in
older copies of the project.

## If you previously saw "BUILD FAILED"
The useful error is normally several lines ABOVE the final Gradle stack trace.
This project also fixes the previous workflow problem where Gradle was installed
manually instead of using the repository wrapper.
