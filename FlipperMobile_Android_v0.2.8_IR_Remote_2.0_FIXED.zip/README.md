# Flipper Mobile Android — v0.2.2

Android companion foundation for Flipper Zero.

## v0.2.2
- BLE permission flow for Android 12+
- BLE scan and Flipper name detection
- GATT connection/disconnection
- Service discovery
- Read-only GATT service/characteristic inspector
- USB device inventory
- Phone NFC/IR capability checks
- Flipper hardware feature placeholders

## Next
1. Map the Flipper Zero BLE transport/protocol.
2. Add transport abstraction for BLE and USB.
3. Implement authenticated/session-safe communication.
4. Add SD-card file browsing and transfer.
5. Add Flipper RPC features behind explicit device connection.

The app does not emulate Flipper hardware radios on Android.


## IR Remote 2.0
The IR screen now includes raw transmission, NEC/Sony protocol generators, a protocol lab, repeats, and locally saved presets. See `IR_REMOTE_2.0.md`.
