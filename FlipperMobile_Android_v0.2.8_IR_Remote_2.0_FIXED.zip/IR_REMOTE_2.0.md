# IR Remote 2.0

IR Remote 2.0 expands the v0.2.8 transmitter into a small protocol toolkit.

## Included

- Raw IR transmission with configurable carrier and microsecond timings.
- NEC 32-bit generator (8-bit address + command with inverse bytes).
- Sony SIRC-12 generator.
- Repeat control.
- Protocol Lab for generating and inspecting timings.
- Local saved remote presets using Android SharedPreferences.
- Quick remote categories for TV, audio and set-top boxes.
- Clear distinction between protocol examples and real device-specific codes.

## Hardware

Transmission requires an Android device that exposes a consumer IR emitter through
`ConsumerIrManager`. The app does not pretend that every Android phone has IR.

## Important

The quick POWER / VOLUME / CHANNEL buttons contain example command bytes. They are
not universal codes. For a real device, enter the address/command from the remote's
documented protocol or use raw timings obtained from a legitimate learning workflow.

Build with the existing GitHub Actions workflows.
