# Flipper Mobile v0.2.8 — IR Remote

## New
- 📺 IR Remote is now visible on the main screen.
- Detects the phone's built-in Consumer IR transmitter.
- Sends raw IR timing arrays directly through Android `ConsumerIrManager`.
- User-selectable carrier frequency.
- Raw timings accept spaces, commas, or semicolons as separators.
- 38 kHz hardware test.
- NEC-style sample loader.
- Clear status/toast messages for success and errors.

## Safety / compatibility
IR transmission only works on phones with an Android-visible consumer IR emitter.
The feature is optional, so devices without an IR blaster can still install the app.


## IR Remote 2.0 feature update
- Added protocol lab, NEC and Sony SIRC-12 generators.
- Added repeat transmission and saved IR presets.
- Added quick remote UI and safer validation.
