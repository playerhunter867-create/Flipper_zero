# v0.2.8 IR transmission fix

Fixed the Android manifest by declaring:

`android.permission.TRANSMIT_IR`

Android defines TRANSMIT_IR as a normal permission for using a device IR transmitter.
The IR Remote screen already uses ConsumerIrManager; this manifest declaration fixes
the Access denied error seen when calling ConsumerIrManager.transmit().
