plugins {
    id("com.android.application")
}

android {
    namespace = "com.flippermobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.flippermobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "0.2.8"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(17)
    }
}
