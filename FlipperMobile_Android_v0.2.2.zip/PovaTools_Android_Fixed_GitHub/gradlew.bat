@echo off
setlocal
set ROOT_DIR=%~dp0
if defined JAVA_HOME set JAVACMD=%JAVA_HOME%\bin\java.exe
if not defined JAVACMD set JAVACMD=java.exe
"%JAVACMD%" -jar "%ROOT_DIR%gradle\wrapper\gradle-wrapper.jar" %*
exit /b %ERRORLEVEL%
