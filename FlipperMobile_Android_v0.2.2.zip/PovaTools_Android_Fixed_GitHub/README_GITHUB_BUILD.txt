GitHub Actions build
====================

The project now includes a working ./gradlew launcher that downloads Gradle 8.9 when it is not cached.

On GitHub:
1. Push the contents of this folder to a repository.
2. Open Actions.
3. Run "Build Flipper Mobile APK" or push to main.
4. Download the APK from the workflow Artifacts.

Local build:
  ./gradlew assembleDebug

The first run requires internet access so Gradle 8.9 can be downloaded.
