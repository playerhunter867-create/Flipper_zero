package com.flippermobile;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.nfc.NfcAdapter;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int BG = 0xff050505;
    private static final int WHITE = 0xfff5f5f5;
    private static final int LIME = 0xffd7ff55;
    private static final int MUTED = 0xff9a9a9a;
    private static final int BT_REQ = 100;

    private BluetoothLeScanner scanner;
    private ScanCallback scanCallback;
    private BluetoothGatt gatt;
    private TextView status;
    private TextView results;
    private final Map<String, String> devices = new LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    @Override
    protected void onDestroy() {
        stopScan();
        disconnect();
        super.onDestroy();
    }

    private TextView label(String value, float size, int color) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(16, 12, 16, 12);
        return v;
    }

    private Button button(String title, final Runnable action) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private LinearLayout root(String title) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setBackgroundColor(BG);

        TextView head = label("🐬  " + title, 20, LIME);
        head.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(head, new LinearLayout.LayoutParams(-1, 64));
        return r;
    }

    private LinearLayout content() {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setPadding(8, 8, 8, 24);
        return b;
    }

    private void showHome() {
        LinearLayout r = root("FLIPPER MOBILE");
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        b.addView(label("FLIPPER ZERO COMPANION", 24, WHITE));
        b.addView(label("Android companion • v0.2.7", 15, MUTED));
        b.addView(label(connectionText(), 15, LIME));

        b.addView(button("🐬  Flipper / BLE", this::showBle));
        b.addView(button("📡  NFC / RFID", this::showNfc));
        b.addView(button("📻  Sub-GHz", () ->
                showInfo("SUB-GHZ",
                        "Sub-GHz radio control belongs to the connected Flipper Zero hardware.")));
        b.addView(button("🔌  GPIO", () ->
                showInfo("GPIO",
                        "GPIO control belongs to the connected Flipper Zero hardware.")));
        b.addView(button("📱  Phone", () ->
                showInfo("ANDROID",
                        "Android " + Build.VERSION.RELEASE + "\nSDK " + Build.VERSION.SDK_INT +
                                "\n" + Build.MANUFACTURER + " " + Build.MODEL)));
        b.addView(button("⚙  Android Settings",
                () -> startActivity(new Intent(Settings.ACTION_SETTINGS))));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private String connectionText() {
        return gatt == null ? "FLIPPER STATUS: NOT CONNECTED" : "FLIPPER STATUS: CONNECTED";
    }

    private void showBle() {
        stopScan();

        LinearLayout r = root("FLIPPER / BLE");
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        status = label(connectionText(), 15, LIME);
        results = label("No scan results.", 14, WHITE);

        b.addView(label("CONNECT TO FLIPPER ZERO", 22, WHITE));
        b.addView(label("BLE discovery and basic GATT connection foundation.", 14, MUTED));
        b.addView(status);
        b.addView(button("START / STOP BLE SCAN", this::toggleScan));
        b.addView(results);
        b.addView(button("DISCONNECT", this::disconnect));
        b.addView(button("← BACK", this::showHome));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private void toggleScan() {
        if (scanCallback != null) {
            stopScan();
            setStatus("FLIPPER STATUS: NOT CONNECTED");
            return;
        }

        if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, BT_REQ);
            return;
        }

        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            setStatus("Bluetooth is not supported.");
            return;
        }

        if (!adapter.isEnabled()) {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return;
        }

        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            setStatus("BLE scanner unavailable.");
            return;
        }

        devices.clear();
        scanCallback = new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                String address = "unknown";
                String name = "Unknown";

                try {
                    address = device.getAddress();
                    if (result.getScanRecord() != null &&
                            result.getScanRecord().getDeviceName() != null) {
                        name = result.getScanRecord().getDeviceName();
                    }
                    if (name == null || name.isEmpty()) {
                        name = device.getName();
                    }
                } catch (SecurityException ignored) {
                }

                if (name == null || name.isEmpty()) {
                    name = "Unknown";
                }

                String prefix = name.toLowerCase().contains("flipper")
                        ? "🐬 FLIPPER • "
                        : "BLE • ";

                devices.put(address, prefix + name + " • " +
                        address + " • " + result.getRssi() + " dBm");

                runOnUiThread(() -> renderResults());
            }

            @Override
            public void onScanFailed(int errorCode) {
                runOnUiThread(() ->
                        setStatus("BLE scan failed: " + errorCode));
            }
        };

        try {
            scanner.startScan(scanCallback);
            setStatus("FLIPPER STATUS: SCANNING…");
        } catch (SecurityException e) {
            setStatus("Bluetooth permission required.");
        }
    }

    private void renderResults() {
        if (results == null) return;

        if (devices.isEmpty()) {
            results.setText("No BLE devices found yet.");
            return;
        }

        StringBuilder out = new StringBuilder();
        out.append("Found ").append(devices.size()).append(" device(s):\n\n");

        for (Map.Entry<String, String> entry : devices.entrySet()) {
            out.append(entry.getValue()).append("\n");
            out.append("Tap a device below to connect.\n\n");
        }

        results.setText(out.toString());
    }

    private void connect(String address) {
        if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_CONNECT
            }, BT_REQ);
            return;
        }

        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) return;

        try {
            disconnect();
            BluetoothDevice device = adapter.getRemoteDevice(address);
            setStatus("FLIPPER STATUS: CONNECTING…");

            gatt = device.connectGatt(this, false, new BluetoothGattCallback() {
                @Override
                public void onConnectionStateChange(BluetoothGatt g,
                                                     int statusCode,
                                                     int newState) {
                    runOnUiThread(() -> {
                        if (newState == BluetoothProfile.STATE_CONNECTED) {
                            gatt = g;
                            setStatus("FLIPPER STATUS: CONNECTED");
                            try {
                                g.discoverServices();
                            } catch (Exception ignored) {
                            }
                        } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                            if (gatt == g) gatt = null;
                            setStatus("FLIPPER STATUS: DISCONNECTED");
                        }
                    });
                }

                @Override
                public void onServicesDiscovered(BluetoothGatt g,
                                                  int discoveryStatus) {
                    runOnUiThread(() -> {
                        if (discoveryStatus == BluetoothGatt.GATT_SUCCESS) {
                            setStatus("FLIPPER STATUS: CONNECTED • SERVICES READY");
                        } else {
                            setStatus("FLIPPER STATUS: SERVICE DISCOVERY FAILED");
                        }
                    });
                }
            });
        } catch (Exception e) {
            setStatus("FLIPPER STATUS: CONNECTION ERROR");
        }
    }

    private void disconnect() {
        if (gatt != null) {
            try {
                gatt.disconnect();
                gatt.close();
            } catch (Exception ignored) {
            }
            gatt = null;
        }
        if (status != null) {
            status.setText("FLIPPER STATUS: NOT CONNECTED");
        }
    }

    private void stopScan() {
        if (scanner != null && scanCallback != null) {
            try {
                scanner.stopScan(scanCallback);
            } catch (Exception ignored) {
            }
        }
        scanner = null;
        scanCallback = null;
    }

    private void showNfc() {
        LinearLayout r = root("NFC / RFID");
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        NfcAdapter nfc = NfcAdapter.getDefaultAdapter(this);
        b.addView(label("NFC HARDWARE", 22, WHITE));
        b.addView(label(
                nfc == null ? "NFC: NOT PRESENT" :
                        "NFC: PRESENT • " + (nfc.isEnabled() ? "ON" : "OFF"),
                15, MUTED));
        b.addView(button("OPEN NFC SETTINGS",
                () -> startActivity(new Intent(Settings.ACTION_NFC_SETTINGS))));
        b.addView(button("← BACK", this::showHome));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private void showInfo(String title, String message) {
        LinearLayout r = root(title);
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        b.addView(label(title, 22, WHITE));
        b.addView(label(message, 15, MUTED));
        b.addView(button("← BACK", this::showHome));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private void setStatus(String value) {
        if (status != null) status.setText(value);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);

        if (requestCode == BT_REQ) {
            if (results.length > 0 &&
                    results[0] == PackageManager.PERMISSION_GRANTED) {
                setStatus("Bluetooth permission granted.");
            } else {
                setStatus("Bluetooth permission denied.");
            }
        }
    }
}
