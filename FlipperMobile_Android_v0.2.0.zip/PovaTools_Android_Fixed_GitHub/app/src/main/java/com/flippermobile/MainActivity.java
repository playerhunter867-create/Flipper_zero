package com.flippermobile;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.nfc.NfcAdapter;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    static final int BG=0xff050505, PANEL=0xff111111, WHITE=0xfff5f5f5, LIME=0xffd7ff55, MUTED=0xff9a9a9a;
    static final int BT_REQ=100;
    BluetoothLeScanner scanner;
    ScanCallback callback;
    BluetoothGatt gatt;
    Button scanButton;
    TextView scanOutput;
    LinearLayout resultsBox;
    TextView statusOutput;
    final Map<String,String> devices=new LinkedHashMap<>();

    @Override public void onCreate(Bundle b){super.onCreate(b);main();}
    @Override protected void onDestroy(){stopScan();disconnectFlipper();super.onDestroy();}

    TextView text(String s,float size,int color){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setPadding(12,10,12,14); return v;
    }
    Button button(String s,final Runnable r){
        Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(14); b.setAllCaps(false);
        b.setOnClickListener(v->r.run()); return b;
    }
    LinearLayout root(String title){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setBackgroundColor(BG);
        TextView t=text("🐬  "+title,20,LIME); t.setGravity(Gravity.CENTER_VERTICAL); r.addView(t,new LinearLayout.LayoutParams(-1,64));
        return r;
    }
    LinearLayout box(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(10,8,10,20);return b;}

    void main(){
        stopScan();
        LinearLayout r=root("FLIPPER MOBILE"); ScrollView s=new ScrollView(this); LinearLayout b=box();
        b.addView(text("FLIPPER ZERO COMPANION",24,WHITE));
        b.addView(text("Android companion • v0.2.0\nDesigned for Flipper Zero + Android",15,MUTED));
        statusOutput=text(connectionText(),15,LIME); b.addView(statusOutput);
        b.addView(button("🐬  Flipper / BLE",()->flipper()));
        b.addView(button("📁  Files / USB",()->usb()));
        b.addView(button("📡  NFC / RFID",()->nfc()));
        b.addView(button("📺  Infrared",()->ir()));
        b.addView(button("📻  Sub-GHz",()->hardwareInfo("SUB-GHZ", "Sub-GHz control belongs to the connected Flipper Zero. Android does not provide a general Sub-GHz radio API.")));
        b.addView(button("🔌  GPIO",()->hardwareInfo("GPIO", "GPIO access belongs to the connected Flipper Zero hardware. This Android app will act as the mobile controller.")));
        b.addView(button("📱  Phone Hardware",()->phoneHardware()));
        b.addView(button("⚙  Android Settings",()->startActivity(new Intent(Settings.ACTION_SETTINGS))));
        b.addView(text("v0.2.0: BLE connection foundation.
Next: identify Flipper services, establish the mobile protocol layer, then add file browsing/transfer and USB transport.",14,MUTED));
        s.addView(b);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);
    }

    String connectionText(){return gatt==null?"FLIPPER STATUS: NOT CONNECTED":"FLIPPER STATUS: CONNECTED";}

    void flipper(){
        stopScan(); LinearLayout r=root("FLIPPER / BLE"); ScrollView s=new ScrollView(this); LinearLayout b=box();
        b.addView(text("CONNECT TO FLIPPER ZERO",22,WHITE));
        b.addView(text("Scan first. Devices advertising with a name containing ‘Flipper’ are highlighted, but any BLE device can be inspected.",14,MUTED));
        statusOutput=text(connectionText(),15,LIME); b.addView(statusOutput);
        scanButton=button("START BLE SCAN",this::toggleScan); b.addView(scanButton);
        scanOutput=text("No scan results.",13,WHITE); b.addView(scanOutput);
        resultsBox=new LinearLayout(this); resultsBox.setOrientation(LinearLayout.VERTICAL); b.addView(resultsBox);
        b.addView(button("GATT SERVICES",this::showGattServices));
        b.addView(button("DISCONNECT",this::disconnectFlipper));
        b.addView(button("← BACK",this::main));
        s.addView(b);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);
    }

    void toggleScan(){
        if(callback!=null){stopScan();if(scanButton!=null)scanButton.setText("START BLE SCAN");return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},BT_REQ);return;}
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null)return;
        if(!a.isEnabled()){startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));return;}
        scanner=a.getBluetoothLeScanner();devices.clear();
        callback=new ScanCallback(){
            @Override public void onScanResult(int type,ScanResult x){
                BluetoothDevice d=x.getDevice();String addr="unknown",name="Unknown";
                try{addr=d.getAddress();if(x.getScanRecord()!=null&&x.getScanRecord().getDeviceName()!=null)name=x.getScanRecord().getDeviceName();if(name==null||name.isEmpty())name=d.getName();}catch(SecurityException ignored){}
                if(name==null||name.isEmpty())name="Unknown";
                boolean flipper=name.toLowerCase().contains("flipper");
                devices.put(addr,(flipper?"🐬 FLIPPER • ":"BLE • ")+name+" • "+addr+" • RSSI "+x.getRssi()+" dBm");
                runOnUiThread(()->renderScanResults());
            }
            @Override public void onScanFailed(int e){runOnUiThread(()->scanOutput.setText("BLE scan failed: "+e));}
        };
        try{scanner.startScan(callback);scanButton.setText("STOP BLE SCAN");}catch(SecurityException e){scanOutput.setText("Bluetooth permission required.");}
    }

    void renderScanResults(){
        if(resultsBox==null)return;
        resultsBox.removeAllViews();
        if(devices.isEmpty()){scanOutput.setText("No devices found.");return;}
        scanOutput.setText("Found "+devices.size()+" BLE device(s):");
        for(Map.Entry<String,String> e:devices.entrySet()){
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL);
            row.addView(text(e.getValue(),13,WHITE));
            String address=e.getKey();
            row.addView(button("CONNECT",()->connectFlipper(address)));
            resultsBox.addView(row);
        }
    }

    void connectFlipper(String address){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},BT_REQ);return;}
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
        try{
            disconnectFlipper();
            BluetoothDevice d=a.getRemoteDevice(address);
            gatt=d.connectGatt(this,false,new BluetoothGattCallback(){
                @Override public void onConnectionStateChange(BluetoothGatt g,int status,int newState){
                    runOnUiThread(()->{
                        if(newState==BluetoothProfile.STATE_CONNECTED){gatt=g; updateStatus("FLIPPER STATUS: CONNECTED"); try{g.discoverServices();}catch(Exception ignored){}}
                        else if(newState==BluetoothProfile.STATE_DISCONNECTED){if(gatt==g)gatt=null;updateStatus("FLIPPER STATUS: DISCONNECTED");}
                    });
                }
                @Override public void onServicesDiscovered(BluetoothGatt g,int status){runOnUiThread(()->updateStatus(status==BluetoothGatt.GATT_SUCCESS?"FLIPPER STATUS: CONNECTED • SERVICES DISCOVERED":"FLIPPER STATUS: CONNECTED • SERVICE DISCOVERY FAILED"));}
            });
            updateStatus("FLIPPER STATUS: CONNECTING…");
        }catch(Exception e){updateStatus("FLIPPER STATUS: CONNECTION ERROR");}
    }


    void showGattServices(){
        if(gatt==null){
            updateStatus("FLIPPER STATUS: NOT CONNECTED");
            return;
        }
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},BT_REQ);
            return;
        }
        LinearLayout r=root("GATT SERVICES"); ScrollView s=new ScrollView(this); LinearLayout b=box();
        b.addView(text("CONNECTED DEVICE",22,WHITE));
        try{
            java.util.List<android.bluetooth.BluetoothGattService> services=gatt.getServices();
            if(services==null || services.isEmpty()){
                b.addView(text("No GATT services discovered yet. Keep the Flipper connected and try again.",14,MUTED));
            } else {
                b.addView(text("Discovered "+services.size()+" service(s). Read-only inspection for v0.2.0.",14,MUTED));
                for(android.bluetooth.BluetoothGattService service:services){
                    StringBuilder line=new StringBuilder();
                    line.append("SERVICE\n").append(service.getUuid()).append("\n");
                    line.append("Characteristics: ").append(service.getCharacteristics().size());
                    b.addView(text(line.toString(),14,WHITE));
                    for(android.bluetooth.BluetoothGattCharacteristic c:service.getCharacteristics()){
                        b.addView(text("  • "+c.getUuid()+"  properties=0x"+Integer.toHexString(c.getProperties()),12,MUTED));
                    }
                }
            }
        }catch(Exception e){
            b.addView(text("Unable to inspect GATT services: "+e.getMessage(),14,MUTED));
        }
        b.addView(button("← BACK",this::flipper));
        s.addView(b); r.addView(s,new LinearLayout.LayoutParams(-1,0,1)); setContentView(r);
    }

    void updateStatus(String s){if(statusOutput!=null)statusOutput.setText(s);}
    void disconnectFlipper(){if(gatt!=null){try{gatt.disconnect();gatt.close();}catch(Exception ignored){}gatt=null;}updateStatus("FLIPPER STATUS: NOT CONNECTED");}
    void stopScan(){if(scanner!=null&&callback!=null)try{scanner.stopScan(callback);}catch(Exception ignored){}scanner=null;callback=null;}

    void usb(){
        LinearLayout r=root("FILES / USB");ScrollView s=new ScrollView(this);LinearLayout b=box();
        android.hardware.usb.UsbManager m=(android.hardware.usb.UsbManager)getSystemService(Context.USB_SERVICE);
        b.addView(text("USB DEVICES",22,WHITE));
        if(m==null||m.getDeviceList().isEmpty())b.addView(text("No USB devices visible.\nConnect Flipper Zero using a USB-C OTG-capable connection.",15,MUTED));
        else for(android.hardware.usb.UsbDevice d:m.getDeviceList().values())b.addView(text("VID "+d.getVendorId()+" • PID "+d.getProductId()+"\n"+d.getProductName(),15,WHITE));
        b.addView(button("← BACK",this::main));s.addView(b);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);
    }

    void nfc(){LinearLayout r=root("NFC / RFID");ScrollView s=new ScrollView(this);LinearLayout b=box();NfcAdapter a=NfcAdapter.getDefaultAdapter(this);b.addView(text("NFC HARDWARE",22,WHITE));b.addView(text(a==null?"NFC hardware: NOT PRESENT":"NFC hardware: PRESENT • "+(a.isEnabled()?"ON":"OFF"),15,MUTED));b.addView(text("Phone NFC is separate from Flipper Zero RFID/NFC hardware. We will add safe phone-side tools and Flipper transfer later.",14,MUTED));b.addView(button("OPEN NFC SETTINGS",()->startActivity(new Intent(Settings.ACTION_NFC_SETTINGS)));b.addView(button("← BACK",this::main));s.addView(b);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);}
    void ir(){LinearLayout r=root("INFRARED");ScrollView s=new ScrollView(this);LinearLayout b=box();boolean has=getPackageManager().hasSystemFeature(PackageManager.FEATURE_CONSUMER_IR);b.addView(text("CONSUMER IR: "+(has?"AVAILABLE":"NOT DETECTED"),22,WHITE));b.addView(text("If the phone has an IR emitter, a phone-side remote can be implemented. Flipper IR remains available through the connected device.",14,MUTED));b.addView(button("← BACK",this::main));s.addView(b);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);}
    void hardwareInfo(String title,String message){LinearLayout r=root(title);ScrollView s=new ScrollView(this);LinearLayout b=box();b.addView(text(title,22,WHITE));b.addView(text(message,15,MUTED));b.addView(button("← BACK",this::main));s.addView(b);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);}
    void phoneHardware(){LinearLayout r=root("PHONE HARDWARE");ScrollView s=new ScrollView(this);LinearLayout b=box();b.addView(text("ANDROID DEVICE",22,WHITE));b.addView(text("Android "+Build.VERSION.RELEASE+" / SDK "+Build.VERSION.SDK_INT+"\nManufacturer: "+Build.MANUFACTURER+"\nModel: "+Build.MODEL+"\nDevice: "+Build.DEVICE,15,WHITE));SensorManager sm=(SensorManager)getSystemService(Context.SENSOR_SERVICE);int[] t={1,4,2,5,8,6};String[] n={"Accelerometer","Gyroscope","Magnetometer","Light","Proximity","Pressure"};for(int i=0;i<t.length;i++)b.addView(text(n[i]+": "+(sm.getDefaultSensor(t[i])!=null?"AVAILABLE":"not available"),14,MUTED));b.addView(button("TEST VIBRATION",()->{Vibrator v=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);if(v!=null&&v.hasVibrator()){if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(180,VibrationEffect.DEFAULT_AMPLITUDE));else v.vibrate(180);}}));b.addView(button("← BACK",this::main));s.addView(b);r.addView(s,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==BT_REQ&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)updateStatus("Bluetooth permission granted • press START BLE SCAN");}
}
