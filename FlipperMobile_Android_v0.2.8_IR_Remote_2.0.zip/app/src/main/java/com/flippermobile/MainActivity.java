package com.flippermobile;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.ConsumerIrManager;
import android.nfc.NfcAdapter;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int BG = 0xff050505;
    private static final int WHITE = 0xfff5f5f5;
    private static final int LIME = 0xffd7ff55;
    private static final int MUTED = 0xff9a9a9a;
    private static final int BT_REQ = 100;

    private BluetoothLeScanner scanner;
    private ScanCallback scanCallback;
    private BluetoothGatt gatt;
    private TextView status;
    private TextView results;
    private final Map<String, String> devices = new LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    @Override
    protected void onDestroy() {
        stopScan();
        disconnect();
        super.onDestroy();
    }

    private TextView label(String value, float size, int color) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(16, 12, 16, 12);
        return v;
    }

    private EditText field(String value, String hint) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setTextColor(WHITE);
        e.setHintTextColor(MUTED);
        e.setSingleLine(false);
        e.setPadding(16, 12, 16, 12);
        return e;
    }

    private Button button(String title, final Runnable action) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private LinearLayout root(String title) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setBackgroundColor(BG);

        TextView head = label("🐬  " + title, 20, LIME);
        head.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(head, new LinearLayout.LayoutParams(-1, 64));
        return r;
    }

    private LinearLayout content() {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setPadding(8, 8, 8, 24);
        return b;
    }

    private void showHome() {
        LinearLayout r = root("FLIPPER MOBILE");
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        b.addView(label("FLIPPER ZERO COMPANION", 24, WHITE));
        b.addView(label("Android companion • v0.2.8", 15, MUTED));
        b.addView(label(connectionText(), 15, LIME));

        b.addView(button("🐬  Flipper / BLE", this::showBle));
        b.addView(button("📡  NFC / RFID", this::showNfc));
        b.addView(button("📻  Sub-GHz", () ->
                showInfo("SUB-GHZ",
                        "Sub-GHz radio control belongs to the connected Flipper Zero hardware.")));
        b.addView(button("🔌  GPIO", () ->
                showInfo("GPIO",
                        "GPIO control belongs to the connected Flipper Zero hardware.")));
        b.addView(button("📺  IR Remote", this::showIrRemote));
        b.addView(button("📱  Phone", () ->
                showInfo("ANDROID",
                        "Android " + Build.VERSION.RELEASE + "\nSDK " + Build.VERSION.SDK_INT +
                                "\n" + Build.MANUFACTURER + " " + Build.MODEL)));
        b.addView(button("⚙  Android Settings",
                () -> startActivity(new Intent(Settings.ACTION_SETTINGS))));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private String connectionText() {
        return gatt == null ? "FLIPPER STATUS: NOT CONNECTED" : "FLIPPER STATUS: CONNECTED";
    }

    private void showBle() {
        stopScan();

        LinearLayout r = root("FLIPPER / BLE");
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        status = label(connectionText(), 15, LIME);
        results = label("No scan results.", 14, WHITE);

        b.addView(label("CONNECT TO FLIPPER ZERO", 22, WHITE));
        b.addView(label("BLE discovery and basic GATT connection foundation.", 14, MUTED));
        b.addView(status);
        b.addView(button("START / STOP BLE SCAN", this::toggleScan));
        b.addView(results);
        b.addView(button("DISCONNECT", this::disconnect));
        b.addView(button("← BACK", this::showHome));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private void toggleScan() {
        if (scanCallback != null) {
            stopScan();
            setStatus("FLIPPER STATUS: NOT CONNECTED");
            return;
        }

        if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, BT_REQ);
            return;
        }

        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            setStatus("Bluetooth is not supported.");
            return;
        }

        if (!adapter.isEnabled()) {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return;
        }

        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            setStatus("BLE scanner unavailable.");
            return;
        }

        devices.clear();
        scanCallback = new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                String address = "unknown";
                String name = "Unknown";

                try {
                    address = device.getAddress();
                    if (result.getScanRecord() != null &&
                            result.getScanRecord().getDeviceName() != null) {
                        name = result.getScanRecord().getDeviceName();
                    }
                    if (name == null || name.isEmpty()) {
                        name = device.getName();
                    }
                } catch (SecurityException ignored) {
                }

                if (name == null || name.isEmpty()) {
                    name = "Unknown";
                }

                String prefix = name.toLowerCase().contains("flipper")
                        ? "🐬 FLIPPER • "
                        : "BLE • ";

                devices.put(address, prefix + name + " • " +
                        address + " • " + result.getRssi() + " dBm");

                runOnUiThread(this::renderResults);
            }

            private void renderResults() {
                MainActivity.this.renderResults();
            }

            @Override
            public void onScanFailed(int errorCode) {
                runOnUiThread(() ->
                        setStatus("BLE scan failed: " + errorCode));
            }
        };

        try {
            scanner.startScan(scanCallback);
            setStatus("FLIPPER STATUS: SCANNING…");
        } catch (SecurityException e) {
            setStatus("Bluetooth permission required.");
        }
    }

    private void renderResults() {
        if (results == null) return;

        if (devices.isEmpty()) {
            results.setText("No BLE devices found yet.");
            return;
        }

        StringBuilder out = new StringBuilder();
        out.append("Found ").append(devices.size()).append(" device(s):\n\n");

        for (Map.Entry<String, String> entry : devices.entrySet()) {
            out.append(entry.getValue()).append("\n");
            out.append("Tap a device below to connect.\n\n");
            String address = entry.getKey();
            // Connection buttons are rebuilt below.
        }

        results.setText(out.toString());
    }

    private void connect(String address) {
        if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_CONNECT
            }, BT_REQ);
            return;
        }

        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) return;

        try {
            disconnect();
            BluetoothDevice device = adapter.getRemoteDevice(address);
            setStatus("FLIPPER STATUS: CONNECTING…");

            gatt = device.connectGatt(this, false, new BluetoothGattCallback() {
                @Override
                public void onConnectionStateChange(BluetoothGatt g,
                                                     int statusCode,
                                                     int newState) {
                    runOnUiThread(() -> {
                        if (newState == BluetoothProfile.STATE_CONNECTED) {
                            gatt = g;
                            setStatus("FLIPPER STATUS: CONNECTED");
                            try {
                                g.discoverServices();
                            } catch (Exception ignored) {
                            }
                        } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                            if (gatt == g) gatt = null;
                            setStatus("FLIPPER STATUS: DISCONNECTED");
                        }
                    });
                }

                @Override
                public void onServicesDiscovered(BluetoothGatt g,
                                                  int discoveryStatus) {
                    runOnUiThread(() -> {
                        if (discoveryStatus == BluetoothGatt.GATT_SUCCESS) {
                            setStatus("FLIPPER STATUS: CONNECTED • SERVICES READY");
                        } else {
                            setStatus("FLIPPER STATUS: SERVICE DISCOVERY FAILED");
                        }
                    });
                }
            });
        } catch (Exception e) {
            setStatus("FLIPPER STATUS: CONNECTION ERROR");
        }
    }

    private void disconnect() {
        if (gatt != null) {
            try {
                gatt.disconnect();
                gatt.close();
            } catch (Exception ignored) {
            }
            gatt = null;
        }
        if (status != null) {
            status.setText("FLIPPER STATUS: NOT CONNECTED");
        }
    }

    private void stopScan() {
        if (scanner != null && scanCallback != null) {
            try {
                scanner.stopScan(scanCallback);
            } catch (Exception ignored) {
            }
        }
        scanner = null;
        scanCallback = null;
    }

    private void showNfc() {
        LinearLayout r = root("NFC / RFID");
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        NfcAdapter nfc = NfcAdapter.getDefaultAdapter(this);
        b.addView(label("NFC HARDWARE", 22, WHITE));
        b.addView(label(
                nfc == null ? "NFC: NOT PRESENT" :
                        "NFC: PRESENT • " + (nfc.isEnabled() ? "ON" : "OFF"),
                15, MUTED));
        b.addView(button("OPEN NFC SETTINGS",
                () -> startActivity(new Intent(Settings.ACTION_NFC_SETTINGS))));
        b.addView(button("← BACK", this::showHome));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private void showIrRemote() {
        LinearLayout r = root("IR REMOTE 2.0");
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        ConsumerIrManager ir =
                (ConsumerIrManager) getSystemService(CONSUMER_IR_SERVICE);
        boolean available = ir != null && ir.hasIrEmitter();

        b.addView(label("📺 IR REMOTE 2.0", 24, WHITE));
        b.addView(label(
                available
                        ? "PHONE IR: READY • universal transmitter"
                        : "PHONE IR: NOT AVAILABLE",
                15, available ? LIME : MUTED));

        if (!available) {
            b.addView(label(
                    "Your phone does not expose a built-in consumer IR emitter to Android. " +
                    "The protocol tools below can still be used to prepare signals.",
                    14, MUTED));
        }

        b.addView(label("QUICK REMOTE", 18, WHITE));
        b.addView(button("📺 TV • NEC", () -> showIrProtocol("NEC TV", "NEC")));
        b.addView(button("🔊 AUDIO • NEC", () -> showIrProtocol("AUDIO • NEC", "NEC")));
        b.addView(button("📦 SET-TOP BOX • NEC", () -> showIrProtocol("SET-TOP • NEC", "NEC")));
        b.addView(button("🧪 PROTOCOL LAB", this::showIrLab));
        b.addView(button("💾 SAVED REMOTES", this::showSavedIr));

        b.addView(label("RAW TRANSMITTER", 18, WHITE));
        b.addView(label("Carrier frequency (Hz)", 14, MUTED));
        EditText frequency = field("38000", "e.g. 38000");
        frequency.setSingleLine(true);
        b.addView(frequency);

        b.addView(label("Raw timings (microseconds)", 14, MUTED));
        EditText raw = field(
                "9000 4500 560 560 560 1690 560 560 560 560",
                "MARK SPACE MARK SPACE ...");
        b.addView(raw);

        b.addView(button("SEND RAW IR", () ->
                transmitRawFromFields(frequency.getText().toString(), raw.getText().toString())));

        b.addView(button("LOAD NEC TEST", () ->
                raw.setText("9000 4500 560 560 560 1690 560 560 560 560 560 560 560 1690 560 560")));

        b.addView(label(
                "IR 2.0 supports raw timings plus protocol generators for NEC and Sony SIRC. " +
                "Codes are not device-specific until you enter the address/command from your remote.",
                13, MUTED));

        b.addView(button("← BACK", this::showHome));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private void showIrProtocol(String title, String protocol) {
        showIrProtocol(title, protocol, "0", "0", "38000");
    }

    private void showIrProtocol(String title, String protocol, String savedAddress,
                                String savedCommand, String savedFrequency) {
        LinearLayout r = root("IR • " + title);
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        b.addView(label(title, 22, WHITE));
        b.addView(label(
                protocol.equals("NEC")
                        ? "NEC 32-bit • address + command • 38 kHz"
                        : protocol,
                14, MUTED));

        EditText address = field(savedAddress, "Address (0–255)");
        address.setSingleLine(true);
        EditText command = field(savedCommand, "Command (0–255)");
        command.setSingleLine(true);
        EditText frequency = field(savedFrequency, "Carrier Hz");
        frequency.setSingleLine(true);
        EditText repeats = field("1", "Repeats");
        repeats.setSingleLine(true);

        b.addView(label("Device address", 14, MUTED));
        b.addView(address);
        b.addView(label("Command", 14, MUTED));
        b.addView(command);
        b.addView(label("Carrier", 14, MUTED));
        b.addView(frequency);
        b.addView(label("Repeat count", 14, MUTED));
        b.addView(repeats);

        b.addView(button("⏻ POWER", () -> sendProtocolCommand(protocol, address, command, frequency, repeats, 0x12)));
        b.addView(button("🔊 VOL +", () -> sendProtocolCommand(protocol, address, command, frequency, repeats, 0x40)));
        b.addView(button("🔉 VOL −", () -> sendProtocolCommand(protocol, address, command, frequency, repeats, 0x41)));
        b.addView(button("📺 CH +", () -> sendProtocolCommand(protocol, address, command, frequency, repeats, 0x20)));
        b.addView(button("📺 CH −", () -> sendProtocolCommand(protocol, address, command, frequency, repeats, 0x21)));

        b.addView(button("SEND ENTERED COMMAND", () ->
                sendProtocolCommand(protocol, address, command, frequency, repeats, -1)));

        b.addView(button("💾 SAVE REMOTE", () ->
                saveIrPreset(title, address.getText().toString(), command.getText().toString(),
                        frequency.getText().toString(), protocol)));

        b.addView(label(
                "Important: POWER/VOL/CH are example command bytes, not universal TV codes. " +
                "For a real device, use the learned/raw code or its documented protocol values.",
                13, MUTED));

        b.addView(button("← BACK", this::showIrRemote));
        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private void sendProtocolCommand(String protocol, EditText addressField,
                                     EditText commandField, EditText frequencyField,
                                     EditText repeatsField, int overrideCommand) {
        try {
            int address = Integer.parseInt(addressField.getText().toString().trim());
            int command = overrideCommand >= 0
                    ? overrideCommand
                    : Integer.parseInt(commandField.getText().toString().trim());
            int frequency = Integer.parseInt(frequencyField.getText().toString().trim());
            int repeats = Integer.parseInt(repeatsField.getText().toString().trim());

            if (address < 0 || address > 255 || command < 0 || command > 255) {
                toast("Address and command must be 0–255.");
                return;
            }
            if (repeats < 1 || repeats > 10) {
                toast("Repeats must be 1–10.");
                return;
            }

            int[] pattern;
            if ("NEC".equals(protocol)) {
                pattern = buildNec(address, command, repeats);
            } else {
                pattern = buildSonySirc12(address, command, repeats);
                frequency = 40000;
            }
            transmitIr(frequency, pattern);
        } catch (NumberFormatException e) {
            toast("Enter valid numbers.");
        }
    }

    private int[] buildNec(int address, int command, int repeats) {
        ArrayList<Integer> p = new ArrayList<>();
        int invAddress = (~address) & 0xff;
        int invCommand = (~command) & 0xff;

        for (int r = 0; r < repeats; r++) {
            addNecFrame(p, address, invAddress, command, invCommand);
            if (r + 1 < repeats) {
                // NEC repeat gap. We use a full repeat frame so most receivers
                // accept repeated button presses without relying on a hidden API.
                p.add(9000);
                p.add(2250);
                p.add(560);
            }
        }
        return toIntArray(p);
    }

    private void addNecFrame(List<Integer> p, int address, int invAddress,
                             int command, int invCommand) {
        p.add(9000);
        p.add(4500);
        int[] bytes = {address, invAddress, command, invCommand};
        for (int value : bytes) {
            for (int bit = 0; bit < 8; bit++) {
                p.add(560);
                p.add(((value >> bit) & 1) == 1 ? 1690 : 560);
            }
        }
        p.add(560);
    }

    private int[] buildSonySirc12(int device, int command, int repeats) {
        // Sony SIRC 12-bit: 2400us header, 600us space; LSB first.
        device &= 0x1f;
        command &= 0x7f;
        ArrayList<Integer> p = new ArrayList<>();
        for (int r = 0; r < repeats; r++) {
            p.add(2400);
            p.add(600);
            int bits = command | (device << 7);
            for (int i = 0; i < 12; i++) {
                p.add(((bits >> i) & 1) == 1 ? 1200 : 600);
                p.add(600);
            }
            if (r + 1 < repeats) {
                p.add(45000);
            }
        }
        return toIntArray(p);
    }

    private int[] toIntArray(List<Integer> values) {
        int[] out = new int[values.size()];
        for (int i = 0; i < values.size(); i++) out[i] = values.get(i);
        return out;
    }

    private void showIrLab() {
        LinearLayout r = root("IR PROTOCOL LAB");
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        b.addView(label("PROTOCOL LAB", 22, WHITE));
        b.addView(label(
                "Generate and inspect protocol timing data before transmitting it.",
                14, MUTED));

        EditText necAddress = field("0", "NEC address 0–255");
        necAddress.setSingleLine(true);
        EditText necCommand = field("12", "NEC command 0–255");
        necCommand.setSingleLine(true);
        b.addView(label("NEC 32-bit", 18, WHITE));
        b.addView(necAddress);
        b.addView(necCommand);

        b.addView(button("GENERATE NEC TIMINGS", () -> {
            try {
                int a = Integer.parseInt(necAddress.getText().toString().trim());
                int c = Integer.parseInt(necCommand.getText().toString().trim());
                if (a < 0 || a > 255 || c < 0 || c > 255) throw new NumberFormatException();
                int[] p = buildNec(a, c, 1);
                b.addView(label("Generated " + p.length + " timings", 13, LIME));
                b.addView(label(joinTimings(p), 12, WHITE));
                b.addView(button("SEND GENERATED NEC", () -> transmitIr(38000, p)));
            } catch (NumberFormatException e) {
                toast("Address/command must be 0–255.");
            }
        }));

        EditText sonyDevice = field("1", "Sony device 0–31");
        sonyDevice.setSingleLine(true);
        EditText sonyCommand = field("12", "Sony command 0–127");
        sonyCommand.setSingleLine(true);
        b.addView(label("Sony SIRC-12", 18, WHITE));
        b.addView(sonyDevice);
        b.addView(sonyCommand);
        b.addView(button("SEND SONY SIRC-12", () -> {
            try {
                int d = Integer.parseInt(sonyDevice.getText().toString().trim());
                int c = Integer.parseInt(sonyCommand.getText().toString().trim());
                if (d < 0 || d > 31 || c < 0 || c > 127) throw new NumberFormatException();
                transmitIr(40000, buildSonySirc12(d, c, 1));
            } catch (NumberFormatException e) {
                toast("Sony device must be 0–31, command 0–127.");
            }
        }));

        b.addView(label(
                "This is a signal generator, not an automatic IR database. " +
                "Wrong protocol/address/command will simply control nothing.",
                13, MUTED));
        b.addView(button("← BACK", this::showIrRemote));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private String joinTimings(int[] timings) {
        StringBuilder s = new StringBuilder();
        int limit = Math.min(timings.length, 160);
        for (int i = 0; i < limit; i++) {
            if (i > 0) s.append(' ');
            s.append(timings[i]);
        }
        if (timings.length > limit) s.append(" …");
        return s.toString();
    }

    private void saveIrPreset(String name, String address, String command,
                              String frequency, String protocol) {
        SharedPreferences prefs = getSharedPreferences("ir_remote_2", MODE_PRIVATE);
        String old = prefs.getString("presets", "");
        String line = escapePreset(name) + "|" + escapePreset(address) + "|" +
                escapePreset(command) + "|" + escapePreset(frequency) + "|" + protocol;
        String value = old.isEmpty() ? line : old + "\n" + line;
        prefs.edit().putString("presets", value).apply();
        toast("Remote saved.");
    }

    private String escapePreset(String s) {
        return s.replace("|", " ").replace("\n", " ").trim();
    }

    private void showSavedIr() {
        LinearLayout r = root("SAVED REMOTES");
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();
        SharedPreferences prefs = getSharedPreferences("ir_remote_2", MODE_PRIVATE);
        String saved = prefs.getString("presets", "");

        b.addView(label("SAVED IR 2.0 PRESETS", 22, WHITE));
        if (saved.isEmpty()) {
            b.addView(label("No saved remotes yet.", 15, MUTED));
        } else {
            String[] lines = saved.split("\\n");
            for (String line : lines) {
                String[] parts = line.split("\\|", -1);
                if (parts.length < 5) continue;
                String title = parts[0];
                b.addView(button("📺 " + title + " • " + parts[4] +
                        " • A:" + parts[1] + " C:" + parts[2],
                        () -> showIrProtocol(title, parts[4], parts[1], parts[2], parts[3])));
            }
            b.addView(button("🗑 CLEAR SAVED REMOTES", () -> {
                prefs.edit().remove("presets").apply();
                toast("Saved remotes cleared.");
                showSavedIr();
            }));
        }
        b.addView(label(
                "Saved presets are stored locally in the Android app. " +
                "They do not contain automatically learned codes unless you enter them.",
                13, MUTED));
        b.addView(button("← BACK", this::showIrRemote));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void showInfo(String title, String message) {
        LinearLayout r = root(title);
        ScrollView scroll = new ScrollView(this);
        LinearLayout b = content();

        b.addView(label(title, 22, WHITE));
        b.addView(label(message, 15, MUTED));
        b.addView(button("← BACK", this::showHome));

        scroll.addView(b);
        r.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(r);
    }

    private void setStatus(String value) {
        if (status != null) status.setText(value);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);

        if (requestCode == BT_REQ) {
            if (results.length > 0 &&
                    results[0] == PackageManager.PERMISSION_GRANTED) {
                setStatus("Bluetooth permission granted.");
            } else {
                setStatus("Bluetooth permission denied.");
            }
        }
    }
}
