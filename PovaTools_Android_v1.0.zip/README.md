# PovaTools Android v1.0

Native Android starter project for PovaTools.

## Build locally
Use Android Studio or run:
`./gradlew assembleDebug`

## GitHub Actions
The repository can build `app-debug.apk` using the supplied workflow.

## Hardware
NFC and Bluetooth detection are implemented. Other modules are UI entry points until their Android APIs/external hardware are integrated.

This project uses original PovaTools branding and assets; it does not include Flipper Zero proprietary source, firmware, logos, or assets.
