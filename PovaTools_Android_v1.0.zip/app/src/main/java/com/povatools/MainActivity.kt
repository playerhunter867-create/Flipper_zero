package com.povatools

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.pm.PackageManager
import android.nfc.NfcAdapter
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Color

class MainActivity : android.app.Activity() {
    private val lime=Color.rgb(215,255,85)
    private val bg=Color.rgb(5,5,5)
    private val panel=Color.rgb(17,17,17)
    private val white=Color.rgb(245,245,245)
    private val muted=Color.rgb(139,139,139)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMain()
    }

    private fun base(): LinearLayout {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setBackgroundColor(bg)
        val bar=LinearLayout(this); bar.gravity=Gravity.CENTER_VERTICAL; bar.setPadding(16,10,16,10)
        val title=TextView(this); title.text="POVATOOLS"; title.textColor=white; title.textSize=17f; title.typeface=android.graphics.Typeface.DEFAULT_BOLD
        bar.addView(title, LinearLayout.LayoutParams(0,58,1f))
        val dot=TextView(this); dot.text="●"; dot.textColor=lime; dot.textSize=18f; bar.addView(dot)
        root.addView(bar)
        return root
    }
    private fun button(text:String, action:()->Unit): Button {
        val b=Button(this); b.text=text; b.setTextColor(white); b.setBackgroundColor(panel); b.setOnClickListener{action()}
        b.textSize=15f; b.gravity=Gravity.CENTER_VERTICAL; b.setPadding(18,8,18,8)
        return b
    }
    private fun showMain() {
        val root=base(); val scroll=ScrollView(this); val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(14,10,14,30)
        val h=TextView(this); h.text="MAIN MENU"; h.textColor=white; h.textSize=22f; h.setPadding(4,10,4,14); box.addView(h)
        val items=listOf("📻  Sub-GHz","📡  NFC","🪪  RFID","📺  Infrared","🔌  GPIO / USB","🔑  iButton","🔵  BLE","⚙  Settings","ⓘ  Device Info")
        items.forEachIndexed{ i,t -> box.addView(button(t){showTool(i,t) },LinearLayout.LayoutParams(-1,64).apply{setMargins(0,0,0,7)})}
        scroll.addView(box); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun showTool(i:Int,title:String) {
        val root=base(); val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(16,20,16,20)
        val h=TextView(this); h.text=title; h.textColor=white; h.textSize=22f; box.addView(h)
        val status=TextView(this); status.setPadding(0,18,0,18); status.textColor=muted
        status.text=when(i){
            1 -> if(NfcAdapter.getDefaultAdapter(this)!=null) "NFC hardware detected. Native NFC actions can be added here." else "NFC hardware not detected."
            6 -> if(BluetoothAdapter.getDefaultAdapter()!=null) "Bluetooth adapter detected. BLE actions can be added here." else "Bluetooth not detected."
            8 -> "Android "+android.os.Build.VERSION.RELEASE+" • "+android.os.Build.MODEL
            else -> "Ready. This module may require native Android APIs or external hardware."
        }
        box.addView(status)
        if(i==8){ val b=button("Open Android Settings"){startActivity(android.content.Intent(Settings.ACTION_SETTINGS))};box.addView(b,LinearLayout.LayoutParams(-1,60))}
        val back=button("←  BACK"){showMain()};box.addView(back,LinearLayout.LayoutParams(-1,60).apply{setMargins(0,20,0,0)})
        root.addView(box);setContentView(root)
    }
}
