plugins {
    id("com.android.application")
}
android {
    namespace = "com.flippermobile"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.flippermobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.2.5"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(17)
    }
}
