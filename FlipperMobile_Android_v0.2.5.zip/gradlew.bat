@echo off
set DIR=%~dp0
if defined JAVA_HOME set JAVA_CMD=%JAVA_HOME%\bin\java.exe
if not defined JAVA_CMD set JAVA_CMD=java.exe
"%JAVA_CMD%" -jar "%DIR%gradle\wrapper\gradle-wrapper.jar" %*
if errorlevel 1 exit /b %errorlevel%
