# v0.2.3

- Fixed Gradle Wrapper Java class-version mismatch: wrapper launcher is compiled for Java 17.
- Pinned Gradle 8.11.1 and its official SHA-256 distribution checksum.
- GitHub Actions uses JDK 17, matching Android Gradle Plugin 8.9 requirements.
- CI validates the wrapper JAR checksum before building.
- CI uses the project Wrapper as the single Gradle source of truth.
- Debug APK is uploaded as a workflow artifact.
