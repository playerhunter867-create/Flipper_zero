# Flipper Mobile v0.2.5 build notes

CI is intentionally split into two concerns:

1. `validate-wrapper.yml` validates the checked-in Gradle Wrapper.
2. `build-apk.yml` builds with pinned Gradle 8.11.1 through `gradle/actions/setup-gradle`.

Android build compatibility is:
- AGP 8.9.3
- Gradle 8.11.1
- JDK 17
- compileSdk/targetSdk 35
- Build Tools 35.0.0

The build workflow does not invoke `./gradlew`; this prevents an old or malformed wrapper binary
from blocking the APK build. The project still contains a validated wrapper for local development.
