# v0.2.7 build

This is a deliberately minimal, dependency-free Android build:
- AGP 8.9.3
- Gradle 8.11.1
- JDK 17
- compileSdk/targetSdk 35
- minSdk 26
- no AndroidX dependencies
- no external libraries
- no Gradle Wrapper

The GitHub workflow extracts this ZIP and invokes the pinned Gradle 8.11.1 directly.
Important: GitHub only executes workflow YAML files that are committed under `.github/workflows/`
in the repository itself. If the repository contains only this ZIP, copy
`.github/workflows/build-from-zip.yml` from the ZIP into the repository's `.github/workflows/`
directory once.
