# v0.2.5

- Rebuilt the project as a clean repository-root ZIP (no extra top-level project directory).
- Fixed an invalid Java multiline string in `MainActivity.java`.
- Added an explicit Java 17 toolchain.
- Kept AGP 8.9.3 / Gradle 8.11.1 / SDK 35 compatibility.
- Added strict Wrapper manifest/class-version validation.
- Added dedicated Gradle Wrapper validation workflow.
- Changed APK CI to use pinned Gradle 8.11.1 directly, avoiding stale/broken wrapper failures.
- Added APK existence/type verification before artifact upload.
