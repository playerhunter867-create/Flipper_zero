# Flipper Mobile v0.2.2

- Fixed the Gradle Wrapper setup.
- Added `gradle/wrapper/gradle-wrapper.jar`.
- Pinned Gradle to 8.11.1.
- Pinned Android Gradle Plugin to 8.9.3.
- Added a GitHub Actions workflow using JDK 17 and Android SDK 35.
- Added APK artifact upload and build verification.
