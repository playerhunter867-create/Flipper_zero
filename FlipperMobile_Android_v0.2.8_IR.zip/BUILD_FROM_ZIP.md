# Flipper Mobile v0.2.6

This project is intentionally CI-first.

GitHub Actions does NOT invoke the project's Gradle Wrapper. It:
1. finds the ZIP in the repository;
2. extracts it;
3. locates `settings.gradle(.kts)`;
4. installs JDK 17 and Android SDK 35;
5. installs Gradle 8.11.1;
6. runs `gradle clean assembleDebug`;
7. uploads `FlipperMobile-debug.apk`.

The repository does not contain a Gradle Wrapper on purpose, so a malformed
`gradle-wrapper.jar` cannot break the GitHub build.
