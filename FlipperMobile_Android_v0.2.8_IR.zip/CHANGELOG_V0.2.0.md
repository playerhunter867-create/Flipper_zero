# v0.2.0

## Added
- Real BLE GATT connection lifecycle.
- GATT service discovery.
- Read-only UUID/property inspector.
- Version bump to 0.2.0.

## Safety / scope
This release only establishes connectivity and inspection. It does not send arbitrary RF/NFC/GPIO commands.
