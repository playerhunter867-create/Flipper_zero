package com.flippermobile;

import android.content.Context;
import android.hardware.ConsumerIrManager;

/**
 * Flipper Mobile v0.2.8 - local Android IR transmitter.
 */
public final class IrRemoteManager {
    private final ConsumerIrManager ir;

    public IrRemoteManager(Context context) {
        ir = (ConsumerIrManager) context.getSystemService(Context.CONSUMER_IR_SERVICE);
    }

    public boolean isAvailable() {
        return ir != null && ir.hasIrEmitter();
    }

    public boolean transmitRaw(int frequencyHz, int[] durationsMicros) {
        if (!isAvailable() || durationsMicros == null || durationsMicros.length == 0) {
            return false;
        }
        try {
            ir.transmit(frequencyHz, durationsMicros);
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    public boolean test38k() {
        return transmitRaw(38000, new int[] {
            9000, 4500,
            560, 560, 560, 1690, 560, 560, 560, 560
        });
    }
}
