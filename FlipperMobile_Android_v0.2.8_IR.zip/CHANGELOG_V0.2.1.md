# Flipper Mobile v0.2.1

## Build fix

- Fixed GitHub Actions / local `./gradlew` failure caused by the missing `gradle-wrapper.jar`.
- Replaced the broken placeholder `gradlew` with a self-contained launcher that downloads Gradle 8.9 when needed.
- Added `gradle/wrapper/gradle-wrapper.properties` for Gradle 8.9.
- Updated the APK workflow to build through `./gradlew`.
