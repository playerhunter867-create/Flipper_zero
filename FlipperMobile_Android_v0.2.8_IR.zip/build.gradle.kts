plugins {
    id("com.android.application") version "8.9.3" apply false
}
