# Flipper Mobile 0.2.8 — IR Remote

## Added
- Android Consumer IR transmitter support.
- Raw IR transmission using frequency + microsecond mark/space durations.
- IR hardware detection via `ConsumerIrManager.hasIrEmitter()`.
- 38 kHz test burst for hardware verification.
- `IrRemoteManager` helper for reuse by the UI.
- `android.hardware.consumerir` declared as an optional device feature.

## Important
IR transmission is performed by the Android phone itself. A phone without an IR emitter
will report the feature as unavailable.

Raw timings must be valid positive microsecond durations. The carrier frequency is supplied
separately (commonly 36/38/40/56 kHz depending on the protocol/device).
