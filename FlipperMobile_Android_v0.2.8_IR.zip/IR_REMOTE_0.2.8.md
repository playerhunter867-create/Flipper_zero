# IR Remote API

The 0.2.8 release adds local IR transmission.

Example:

```java
IrRemoteManager ir = new IrRemoteManager(this);
if (ir.isAvailable()) {
    ir.transmitRaw(38000, new int[] {
        9000, 4500,
        560, 560, 560, 1690
    });
}
```

The array alternates mark/space durations in microseconds.
