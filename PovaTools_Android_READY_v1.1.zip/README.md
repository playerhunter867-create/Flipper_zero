# PovaTools Android v1.1 READY

## Important
This ZIP is the **project root**. Upload the CONTENTS of this ZIP to the root of your GitHub repository, not the ZIP file itself.

Required wrapper files:
- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.jar`
- `gradle/wrapper/gradle-wrapper.properties`

## GitHub
1. Create/open a repository.
2. Upload all files from this ZIP.
3. Commit to `main`.
4. Open **Actions**.
5. Choose **Build PovaTools APK**.
6. Press **Run workflow**.
7. Download `PovaTools-debug-apk` from the completed run.

The project is a native Android starter. NFC and Bluetooth detection are included; additional hardware features require compatible device APIs/external hardware.
