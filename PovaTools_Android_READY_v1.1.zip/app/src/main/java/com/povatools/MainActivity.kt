package com.povatools

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.content.Intent
import android.graphics.Color
import android.nfc.NfcAdapter
import android.bluetooth.BluetoothAdapter
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val bg=Color.rgb(5,5,5); private val panel=Color.rgb(17,17,17)
    private val white=Color.rgb(245,245,245); private val lime=Color.rgb(215,255,85); private val muted=Color.rgb(139,139,139)
    private val tools=listOf(
        "📻  Sub-GHz","📡  NFC","🪪  RFID","📺  Infrared","🔌  GPIO / USB",
        "🔑  iButton","🔵  BLE","⚙  Settings","ⓘ  Device Info"
    )
    override fun onCreate(b:Bundle?){super.onCreate(b);showMain()}
    private fun base():LinearLayout{
        val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setBackgroundColor(bg)
        val bar=LinearLayout(this);bar.gravity=Gravity.CENTER_VERTICAL;bar.setPadding(16,8,16,8)
        val t=TextView(this);t.text="POVATOOLS";t.textColor=white;t.textSize=17f;t.typeface=android.graphics.Typeface.DEFAULT_BOLD
        bar.addView(t,LinearLayout.LayoutParams(0,58,1f));val d=TextView(this);d.text="●";d.textColor=lime;d.textSize=18f;bar.addView(d)
        r.addView(bar);return r
    }
    private fun btn(text:String,click:()->Unit):Button{
        val b=Button(this);b.text=text;b.textColor=white;b.textSize=14f;b.gravity=Gravity.CENTER_VERTICAL
        b.setBackgroundColor(panel);b.setPadding(18,4,18,4);b.setOnClickListener{click()};return b
    }
    private fun showMain(){
        val r=base();val sv=ScrollView(this);val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(14,12,14,24)
        val h=TextView(this);h.text="MAIN MENU";h.textColor=white;h.textSize=22f;h.setPadding(4,8,4,14);box.addView(h)
        tools.forEachIndexed{i,x->box.addView(btn(x){showTool(i,x)},LinearLayout.LayoutParams(-1,62).apply{setMargins(0,0,0,7)})}
        sv.addView(box);r.addView(sv,LinearLayout.LayoutParams(-1,0,1f));setContentView(r)
    }
    private fun showTool(i:Int,title:String){
        val r=base();val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(16,18,16,20)
        val h=TextView(this);h.text=title;h.textColor=white;h.textSize=22f;box.addView(h)
        val st=TextView(this);st.textColor=muted;st.setPadding(0,18,0,18)
        st.text=when(i){
            1->if(NfcAdapter.getDefaultAdapter(this)!=null)"NFC detected. Ready for native NFC features." else "NFC not detected."
            6->if(BluetoothAdapter.getDefaultAdapter()!=null)"Bluetooth adapter detected. Ready for BLE features." else "Bluetooth not detected."
            7->"PovaTools settings."
            8->"Android ${Build.VERSION.RELEASE} • ${Build.MANUFACTURER} ${Build.MODEL}"
            else->"UI module ready. Real hardware access may require Android APIs or external hardware."
        };box.addView(st)
        if(i==7)box.addView(btn("Open Android Settings"){startActivity(Intent(Settings.ACTION_SETTINGS))},LinearLayout.LayoutParams(-1,60))
        box.addView(btn("← BACK"){showMain()},LinearLayout.LayoutParams(-1,60).apply{setMargins(0,16,0,0)})
        r.addView(box);setContentView(r)
    }
}
