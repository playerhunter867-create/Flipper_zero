package com.flippermobile

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var irManager: ConsumerIrManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        irManager = getSystemService(Context.CONSUMER_IR_SERVICE) as ConsumerIrManager

        val status = findViewById<TextView>(R.id.statusText)
        val rawInput = findViewById<EditText>(R.id.rawInput)

        status.text =
            if (irManager.hasIrEmitter()) "IR Blaster: OK"
            else "IR Blaster: NOT SUPPORTED"

        findViewById<Button>(R.id.btnPower).setOnClickListener {
            sendRaw(
                38000,
                intArrayOf(
                    9000, 4500,
                    560, 560, 560, 1690,
                    560, 560, 560, 1690,
                    560, 1690, 560, 560
                )
            )
        }

        findViewById<Button>(R.id.btnVolUp).setOnClickListener {
            sendRaw(38000, intArrayOf(9000, 4500, 560, 560, 560, 560))
        }

        findViewById<Button>(R.id.btnVolDown).setOnClickListener {
            sendRaw(38000, intArrayOf(9000, 4500, 560, 1690, 560, 560))
        }

        findViewById<Button>(R.id.btnMute).setOnClickListener {
            sendRaw(38000, intArrayOf(9000, 4500, 560, 1690, 560, 1690))
        }

        findViewById<Button>(R.id.btnSendRaw).setOnClickListener {
            val pattern = rawInput.text.toString()
                .trim()
                .split(Regex("\\s+"))
                .mapNotNull { it.toIntOrNull() }
                .toIntArray()

            if (pattern.isNotEmpty()) {
                sendRaw(38000, pattern)
            }
        }
    }

    private fun sendRaw(freq: Int, pattern: IntArray) {
        if (irManager.hasIrEmitter()) {
            irManager.transmit(freq, pattern)
        }
    }
}
