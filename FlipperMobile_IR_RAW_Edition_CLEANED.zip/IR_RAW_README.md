# IR RAW Edition

Этот проект содержит базовый движок отправки сырых ИК-команд через ConsumerIrManager.

## Возможности

- POWER
- VOL+/VOL-
- MUTE
- RAW SEND
- Поддержка частоты 38 кГц
- Совместим с телефонами Android, имеющими IR Blaster
